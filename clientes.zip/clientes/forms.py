# clientes/forms.py
from django import forms
from .models import Cliente

class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = ["nombre", "telefono", "email", "direccion"]
        widgets = {
            "nombre": forms.TextInput(attrs={"placeholder": "Nombre"}),
            "telefono": forms.TextInput(attrs={"placeholder": "Teléfono"}),
            "email": forms.EmailInput(attrs={"placeholder": "Correo"}),
            "direccion": forms.TextInput(attrs={"placeholder": "Dirección"}),
        }
