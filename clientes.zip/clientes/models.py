"""
Database models for the clientes app.

The Cliente model stores information about workshop customers. Each
client may have multiple vehicles registered in the system.
"""
from __future__ import annotations

from django.db import models


class Cliente(models.Model):
    """Represents a client of the workshop."""

    nombre = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    direccion = models.CharField(max_length=255, blank=True)
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'cliente'
        verbose_name_plural = 'clientes'
        ordering = ['nombre']

    def __str__(self) -> str:
        return self.nombre