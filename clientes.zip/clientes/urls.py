# clientes/urls.py
from django.urls import path
from . import views

app_name = "clientes"

urlpatterns = [
    path("", views.lista_clientes, name="list"),
    path("nuevo/", views.crear_cliente, name="create"),
    path("<int:pk>/editar/", views.editar_cliente, name="edit"),
    path("<int:pk>/eliminar/", views.eliminar_cliente, name="delete"),
]
