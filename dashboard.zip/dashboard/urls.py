# dashboard/urls.py
from django.urls import path
from . import views

app_name = "dashboard"

urlpatterns = [
    path("", views.home, name="home"),                # portada del dashboard
    path("overview/", views.overview, name="overview"),  # panel BI con filtros y export
]
