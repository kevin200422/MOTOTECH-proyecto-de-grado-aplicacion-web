# dashboard/views.py
from datetime import datetime, timedelta
from collections import defaultdict
from io import StringIO, BytesIO
import csv

from django.shortcuts import render
from django.http import HttpResponse
from django.db.models import Count, Sum, F
from django.db.models.functions import TruncMonth
from django.apps import apps
from django.utils import timezone

from clientes.models import Cliente
from servicios.models import Servicio
from citas.models import Cita


def home(request):
    total_clientes = Cliente.objects.count()
    total_servicios = Servicio.objects.count()
    total_citas = Cita.objects.count()
    return render(request, "dashboard/home.html", {
        "total_clientes": total_clientes,
        "total_servicios": total_servicios,
        "total_citas": total_citas,
    })


# ---------- Helpers ----------
def _parse_date(s):
    """Espera 'YYYY-MM-DD'. Devuelve date o None."""
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return None


def _apply_filters(base_qs, start_date=None, end_date=None, estados=None):
    """
    Aplica filtros al queryset de Cita:
    - start_date/end_date: por fecha_inicio (solo parte fecha)
    - estados: lista de strings (estado)
    """
    qs = base_qs
    if start_date:
        qs = qs.filter(fecha_inicio__date__gte=start_date)
    if end_date:
        qs = qs.filter(fecha_inicio__date__lte=end_date)
    if estados:
        qs = qs.filter(estado__in=estados)
    return qs


def _last_n_months_series(qs):
    """
    Series por mes (12 meses atrás desde HOY o límites de filtro si qs ya viene filtrado):
    Devuelve (labels, citas, ingresos). Labels como 'YYYY-MM'.
    """
    # Si el filtro de fechas recorta menos de 12 meses, Chart mostrará lo que haya.
    per_month = (
        qs.annotate(m=TruncMonth("fecha_inicio"))
          .values("m")
          .annotate(
              citas=Count("id"),
              ingresos=Sum(F("servicio__precio"))
          )
          .order_by("m")
    )
    data_map = {}
    for row in per_month:
        if row["m"]:
            data_map[row["m"].date()] = {
                "citas": int(row["citas"] or 0),
                "ingresos": float(row["ingresos"] or 0.0),
            }

    # Construye eje de meses a partir de lo que devuelve la BD para respetar el filtro
    months_sorted = sorted(list(data_map.keys()))
    labels, citas, ingresos = [], [], []
    for m in months_sorted:
        labels.append(m.strftime("%Y-%m"))
        citas.append(data_map[m]["citas"])
        ingresos.append(data_map[m]["ingresos"])
    return labels, citas, ingresos


def _forecast(values, horizon=3):
    """
    Pronóstico:
    - Si hay statsmodels: Holt-Winters aditivo.
    - Si no: promedio móvil simple (3).
    """
    def simple_ma(vals, h):
        if not vals:
            return [0.0] * h
        w = 3 if len(vals) >= 3 else len(vals)
        base = sum(vals[-w:]) / max(w, 1)
        return [round(base, 2) for _ in range(h)]

    try:
        from statsmodels.tsa.holtwinters import ExponentialSmoothing  # type: ignore
        import numpy as np  # type: ignore
        arr = np.array(values, dtype=float)
        if len(arr) < 4:
            return simple_ma(values, horizon)
        model = ExponentialSmoothing(arr, trend="add", seasonal=None)
        fit = model.fit(optimized=True)
        fc = fit.forecast(horizon)
        return [round(float(x), 2) for x in fc.tolist()]
    except Exception:
        return simple_ma(values, horizon)


def _month_forward_labels(last_label, n=3):
    """
    last_label: 'YYYY-MM' (de las series), devuelve las siguientes n etiquetas mensuales.
    Si no puede parsear, usa sufijos +1, +2...
    """
    if not last_label:
        return [f"+{i}" for i in range(1, n+1)]
    try:
        from dateutil.relativedelta import relativedelta  # pip install python-dateutil (suele venir)
        base = datetime.strptime(last_label + "-01", "%Y-%m-%d").date()
        return [(base + relativedelta(months=i)).strftime("%Y-%m") for i in range(1, n+1)]
    except Exception:
        return [f"{last_label}+{i}" for i in range(1, n+1)]


def _export_csv(qs):
    """
    Exporta CSV de Citas con campos clave.
    """
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = 'attachment; filename="citas.csv"'
    writer = csv.writer(response)
    writer.writerow([
        "ID", "Cliente", "Vehiculo", "Servicio", "PrecioServicio",
        "FechaInicio", "FechaFin", "Estado"
    ])
    qs = qs.select_related("cliente", "vehiculo", "servicio")
    for c in qs:
        cliente = getattr(c.cliente, "nombre", "") if c.cliente_id else ""
        vehiculo = getattr(c.vehiculo, "placa", "") if c.vehiculo_id else ""
        servicio = getattr(c.servicio, "nombre", "") if c.servicio_id else ""
        precio = getattr(c.servicio, "precio", 0) if c.servicio_id else 0
        writer.writerow([
            c.id, cliente, vehiculo, servicio, precio,
            c.fecha_inicio.isoformat() if c.fecha_inicio else "",
            c.fecha_fin.isoformat() if c.fecha_fin else "",
            c.estado or ""
        ])
    return response


def _export_xlsx(qs):
    """
    Exporta XLSX (requiere openpyxl). Si no está, cae a CSV.
    """
    try:
        import openpyxl  # type: ignore
        from openpyxl.utils import get_column_letter  # type: ignore
    except Exception:
        # Fallback
        return _export_csv(qs)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Citas"

    headers = [
        "ID", "Cliente", "Vehiculo", "Servicio", "PrecioServicio",
        "FechaInicio", "FechaFin", "Estado"
    ]
    ws.append(headers)

    qs = qs.select_related("cliente", "vehiculo", "servicio")
    for c in qs:
        cliente = getattr(c.cliente, "nombre", "") if c.cliente_id else ""
        vehiculo = getattr(c.vehiculo, "placa", "") if c.vehiculo_id else ""
        servicio = getattr(c.servicio, "nombre", "") if c.servicio_id else ""
        precio = getattr(c.servicio, "precio", 0) if c.servicio_id else 0
        ws.append([
            c.id, cliente, vehiculo, servicio, precio,
            c.fecha_inicio.isoformat() if c.fecha_inicio else "",
            c.fecha_fin.isoformat() if c.fecha_fin else "",
            c.estado or ""
        ])

    # Auto ancho simple
    for col in ws.columns:
        max_len = 10
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            try:
                max_len = max(max_len, len(str(cell.value)))
            except Exception:
                pass
        ws.column_dimensions[col_letter].width = min(max_len + 2, 40)

    # Responder
    bio = BytesIO()
    wb.save(bio)
    bio.seek(0)
    response = HttpResponse(
        bio.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="citas.xlsx"'
    return response


# ---------- Vista principal ----------
def overview(request):
    """
    Panel BI con filtros (rango de fechas y estado) + export CSV/XLSX.
    Todo el dashboard (KPI, gráficos y tablas) respeta los filtros.
    Si no hay filtros, por defecto se usa rango de 12 meses (hacia atrás) para las series.
    """
    now = timezone.now()
    default_start = (now - timedelta(days=365)).date()
    default_end = now.date()

    # --- Lee filtros ---
    start = _parse_date(request.GET.get("start")) or default_start
    end = _parse_date(request.GET.get("end")) or default_end
    estados = request.GET.getlist("estado")  # lista (puede venir vacía)

    # base queryset
    base = Cita.objects.all()

    # aplica filtros
    qs = _apply_filters(base, start, end, estados)

    # Exportaciones
    export = request.GET.get("export")
    if export == "csv":
        return _export_csv(qs)
    if export == "xlsx":
        return _export_xlsx(qs)

    # KPIs (respetan filtros)
    total_clientes = Cliente.objects.filter(citas__in=qs).distinct().count()
    total_servicios = Servicio.objects.filter(citas__in=qs).distinct().count()
    total_citas = qs.count()

    # Estados (respetan filtros)
    estados_data = (
        qs.values("estado")
          .annotate(total=Count("id"))
          .order_by("-total")
    )

    # Top 5 clientes / servicios (respetan filtros)
    top_clientes = (
        qs.values("cliente__nombre")
          .annotate(num_citas=Count("id"))
          .order_by("-num_citas")[:5]
    )
    top_clientes = [{"nombre": r["cliente__nombre"] or "–", "num_citas": r["num_citas"]} for r in top_clientes]

    top_servicios = (
        qs.values("servicio__nombre")
          .annotate(num_citas=Count("id"))
          .order_by("-num_citas")[:5]
    )
    top_servicios = [{"nombre": r["servicio__nombre"] or "–", "num_citas": r["num_citas"]} for r in top_servicios]

    # Series mensuales y pronóstico (respetan filtros)
    labels, citas_series, ingresos_series = _last_n_months_series(qs)
    forecast_values, forecast_labels = [], []
    if labels:
        forecast_values = _forecast(ingresos_series, horizon=3)
        forecast_labels = _month_forward_labels(labels[-1], n=3)

    # Distinct estados para el multiselect (UI)
    estados_choices = (
        base.values_list("estado", flat=True)
            .distinct()
            .order_by("estado")
    )

    # Repuestos bajos (inventario) - fuera de filtros
    repuestos_bajos = []
    try:
        Repuesto = apps.get_model("inventario", "Repuesto")
        repuestos_bajos = list(
            Repuesto.objects.filter(stock__lte=F("stock_minimo"))
            .values("codigo", "nombre", "stock", "stock_minimo")
            .order_by("stock")
        )
    except LookupError:
        repuestos_bajos = []

    chart_data = {
        "labels": labels,
        "citas": citas_series,
        "ingresos": ingresos_series,
        "forecast_labels": forecast_labels,
        "forecast": forecast_values,
    }

    context = {
        "total_clientes": total_clientes,
        "total_servicios": total_servicios,
        "total_citas": total_citas,
        "estados": list(estados_data),
        "top_clientes": top_clientes,
        "top_servicios": top_servicios,
        "repuestos_bajos": repuestos_bajos,
        "chart_data": chart_data,

        # Filtros actuales
        "f_start": start.isoformat(),
        "f_end": end.isoformat(),
        "f_estados": estados or [],
        "estados_choices": [e for e in estados_choices if e],  # limpia None/'' para el select
    }
    return render(request, "dashboard/overview.html", context)
