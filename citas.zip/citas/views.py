# citas/views.py
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from .models import Cita
from .forms import CitaForm

@login_required
def lista_citas(request):
    citas = Cita.objects.select_related("cliente", "vehiculo", "servicio").order_by("-fecha_inicio")
    return render(request, "citas/list.html", {"citas": citas})

@login_required
def crear_cita(request):
    if request.method == "POST":
        form = CitaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Cita creada correctamente.")
            return redirect("citas:list")
    else:
        form = CitaForm()
    return render(request, "citas/form.html", {"form": form, "accion": "Nueva"})

@login_required
def editar_cita(request, pk):
    cita = get_object_or_404(Cita, pk=pk)
    if request.method == "POST":
        form = CitaForm(request.POST, instance=cita)
        if form.is_valid():
            form.save()
            messages.success(request, "Cita actualizada correctamente.")
            return redirect("citas:list")
    else:
        form = CitaForm(instance=cita)
    return render(request, "citas/form.html", {"form": form, "accion": "Editar"})
