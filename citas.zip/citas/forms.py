# citas/forms.py
from django import forms
from .models import Cita
from clientes.models import Cliente
from servicios.models import Servicio
from vehiculos.models import Vehiculo
from contextlib import suppress

class CitaForm(forms.ModelForm):
    cliente = forms.ModelChoiceField(
        queryset=Cliente.objects.all().order_by("nombre"),
        required=True,
        label="Cliente",
        help_text="Selecciona el cliente",
    )
    servicio = forms.ModelChoiceField(
        queryset=Servicio.objects.filter(activo=True).order_by("nombre"),
        required=True,
        label="Servicio",
    )

    class Meta:
        model = Cita
        fields = ["cliente", "vehiculo", "servicio", "fecha_inicio", "fecha_fin", "estado"]
        widgets = {
            "fecha_inicio": forms.DateTimeInput(attrs={"type": "datetime-local"}),
            "fecha_fin": forms.DateTimeInput(attrs={"type": "datetime-local"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Mostrar "Nombre · Teléfono" en el combo de clientes
        self.fields["cliente"].label_from_instance = (
            lambda c: f"{c.nombre}" + (f" · {c.telefono}" if c.telefono else "")
        )

        # Filtrado dinámico de vehículos según cliente
        self.fields["vehiculo"].queryset = Vehiculo.objects.none()

        if "cliente" in self.data:
            # cuando viene por POST o GET con el cliente seleccionado
            with suppress((TypeError, ValueError)):
                cliente_id = int(self.data.get("cliente"))
                self.fields["vehiculo"].queryset = Vehiculo.objects.filter(
                    cliente_id=cliente_id
                ).order_by("placa")
        elif self.instance.pk and self.instance.cliente_id:
            # cuando se edita una cita existente
            self.fields["vehiculo"].queryset = Vehiculo.objects.filter(
                cliente_id=self.instance.cliente_id
            ).order_by("placa")
