# citas/urls.py
from django.urls import path
from . import views

app_name = "citas"

urlpatterns = [
    path("", views.lista_citas, name="list"),
    path("nueva/", views.crear_cita, name="new"),
    path("<int:pk>/editar/", views.editar_cita, name="edit"),
]
